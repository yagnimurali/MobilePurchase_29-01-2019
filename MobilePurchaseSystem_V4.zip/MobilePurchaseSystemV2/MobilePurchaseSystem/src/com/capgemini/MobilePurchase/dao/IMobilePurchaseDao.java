package com.capgemini.MobilePurchase.dao;

import java.util.List;

import com.capgemini.MobilePurchase.beans.Mobiles;
import com.capgemini.MobilePurchase.beans.Purchasedetails;
import com.capgemini.MobilePurchase.beans.Seller;
import com.capgemini.MobilePurchase.exceptions.MobilePurchaseException;

public interface IMobilePurchaseDao {
	public Purchasedetails purchaseMobile(Purchasedetails pd) throws MobilePurchaseException;

	public int getPurchaseseqId() throws MobilePurchaseException;

	public List<Mobiles> retriveAllDetails() throws MobilePurchaseException;

	public List<Integer> getMobileIds() throws MobilePurchaseException;

	public void updateMobileQuantity(Purchasedetails pd) throws MobilePurchaseException;


	public Mobiles addNewStock(Mobiles ms) throws MobilePurchaseException;
	
	//public List<Seller> authenticateUser() throws MobilePurchaseException;
	
	public void deleteMobile(int mobileId) throws MobilePurchaseException;

	public List<Object> seearchMobile(double minPrice, double maxPrice)
			throws MobilePurchaseException; 

}
