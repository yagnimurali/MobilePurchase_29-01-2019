package com.capgemini.MobilePurchase.beans;

import java.time.LocalDate;

public class Purchasedetails {

	private String MailId;
	private String PhoneNumber;
	private int MobileId;
	private int PurchaseId;
	private LocalDate Purchasedate;
	private String CName;

	public String getCustomerName() {
		return CName;
	}

	public void setCustomerName(String customerName) {
		CName = customerName;
	}

	public String getMailId() {
		return MailId;
	}

	public void setMailId(String mailId) {
		MailId = mailId;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public int getMobileId() {
		return MobileId;
	}

	public void setMobileId(int mobileID2) {
		MobileId = mobileID2;
	}

	public int getPurchaseId() {
		return PurchaseId;
	}

	public void setPurchaseId(int purchaseId2) {
		PurchaseId = purchaseId2;
	}

	public LocalDate getPurchasedate() {
		return Purchasedate;
	}

	public void setPurchasedate(LocalDate purchasedate) {
		Purchasedate = purchasedate;
	}

}
