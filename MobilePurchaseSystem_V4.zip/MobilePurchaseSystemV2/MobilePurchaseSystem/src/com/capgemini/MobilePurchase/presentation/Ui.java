package com.capgemini.MobilePurchase.presentation;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.MobilePurchase.beans.Mobiles;
import com.capgemini.MobilePurchase.beans.Purchasedetails;
import com.capgemini.MobilePurchase.beans.Seller;
import com.capgemini.MobilePurchase.exceptions.MobilePurchaseException;
import com.capgemini.MobilePurchase.service.IMobilePurchaseService;
import com.capgemini.MobilePurchase.service.MobilePurchaseService;

public class Ui {

	private static Scanner in;
	private static IMobilePurchaseService imp = new MobilePurchaseService();

	public static void main(String[] args) throws MobilePurchaseException {
		in = new Scanner(System.in);
		System.out.println(" \nWelcome to mobile purchase portal\n");
		while (true) {
			System.out.println(" \nEnter your choice:");
			System.out.println("\n 1.Customer Portal\n\n 2.Seller Portal\n\n 3.Exit Application\n");
			int option1 = in.nextInt();
			switch (option1) {
			case 1:
				int choice = 0;
				while (choice != 4) {
					System.out.println(" \nEnter your choice:\n");
					System.out.println(" 1.View Mobiles\n");
					System.out.println(" 2.Purchasce mobile\n");
					System.out.println(" 3.Search Mobile\n");
					System.out.println(" 4.Exit\n");
					choice = in.nextInt();
					switch (choice) {

					case 1:
						viewMobiles();
						break;

					case 2:

						int option = 0;
						do {
							getInputs();
							System.out.println("\nTo Purchase more, enter 1. Otherwise press any other Digit");
							option = in.nextInt();
						} while (option == 1);
						break;

					case 3:
						searchMobile();
						break;

					case 4:
						System.out.println("\n\nThank you");
						break;

					}

				}
				break;

			case 2:
				/*System.out.println("Authentication Required, Please provide your Login credentials\n");
				System.out.println("Enter your username");
				String username = in.next();
				System.out.println("Enter your password");
				String password = in.next();
				if (imp.authenticateUser(username, password)) {
					System.out.println("\nVarified seller");
*/
					int choice2 = 0;
					while (choice2 != 4) {
						System.out.println(" \nEnter your choice:\n");
						System.out.println(" 1.Add new Stock\n");
						System.out.println(" 2.View Mobiles\n");
						System.out.println(" 3.Delete Stock\n");
						System.out.println(" 4.Exit\n");
						choice2 = in.nextInt();

						switch (choice2) {

						case 1:
							int option = 0;
							do {
								addNewStockInputs();
								System.out.println("\nTo Add more Stock, enter 1. Otherwise press any other Digit");
								option = in.nextInt();
							} while (option == 1);
							break;

						case 2:
							viewMobiles();
							break;
							
						case 3:
							System.out.println("Enter mobile id");
							int mobileId = in.nextInt();
							imp.deleteMobile(mobileId);

						case 4:
							System.out.println("\n\nThank you");
							break;

						}

					}
				/*} else {
					System.out.println("Not a Varified Seller");
				}*/
				break;
			case 3:
				System.out.println("Have a nice day!!. Goodbye!!. ");
				System.exit(0);
			}
		}
	}

	private static void searchMobile() {
		try {
			List<Object> searchList = new ArrayList<Object>();
			System.out.println("\nEnter Minimum price\n");
			double minPrice = in.nextDouble();
			System.out.println("\nEnter Maximum price\n");
			double maxPrice = in.nextDouble();
			searchList = imp.seearchMobile(minPrice,maxPrice);

			if (searchList != null) {
				Iterator<Object> i = searchList.iterator();
				while (i.hasNext()) {
					Purchasedetails pd1 = (Purchasedetails) i.next();
					Mobiles obj = (Mobiles) i.next();
					System.out.println("Available Mobiles: " + pd1.getPurchaseId() + " " + pd1.getCustomerName() + " "
							+ obj.getName() + "\n");

				}
			} else {
				System.out.println("\nno purchase found with this purchase id\n");
			}

		}

		catch (MobilePurchaseException e) {

			System.out.println("Error  :" + e.getMessage());
		}

	}

	private static void viewMobiles() {
		try {
			List<Mobiles> mobilesList = new ArrayList<Mobiles>();
			mobilesList = imp.retriveAllDetails();

			if (mobilesList != null) {
				Iterator<Mobiles> i = mobilesList.iterator();
				while (i.hasNext()) {
					Mobiles obj = i.next();
					System.out.println(obj.getMobileid() + " " + obj.getName() + " " + obj.getPrice() + " "
							+ obj.getQuantity() + "\n");

				}
			} else {
				System.out.println("\nNo stock available!!\n");
			}

		} catch (MobilePurchaseException e) {

			System.out.println("Error  :" + e.getMessage());
		}

	}

	private static void getInputs() throws MobilePurchaseException {
		Purchasedetails pd = new Purchasedetails();
		try {
			String MailId;
			String PhoneNumber;
			int MobileID = 0;
			LocalDate Purchasedate;
			String CName;

			while (true) {
				in.nextLine();
				System.out.println("Please enter customer name");

				CName = in.nextLine();

				if (imp.validateCustomerName(CName)) {
					//System.out.println("\nvalid customer name");
					break;
				} else {
					System.out.println("Invalid customer name, [valid eg:Yagni]");
				}
			}

			while (true) {
				System.out.println("\nPlease enter mobile id");

				System.out.println(imp.getMobileIds());

				MobileID = in.nextInt();

				String MobileId = Integer.toString(MobileID);

				if (imp.validateMobileId(MobileId)) {
					//System.out.println("\nvalid mobile id");
					if (imp.getMobileIds().contains(MobileID)) {
						break;
					} else {
						System.out.println("Out of stock");
					}

				} else {
					System.out.println("Invalid mobile id, Requires 4 digits");
				}

			}

			Purchasedate = LocalDate.now();

			while (true) {
				System.out.println("Please enter phone number");

				PhoneNumber = in.next();

				if (imp.validatePhoneNumber(PhoneNumber)) {
					//System.out.println("\nvalid phone number");
					break;
				} else {
					System.out.println("Invalid phone number, must be 10 digit");
				}
			}

			while (true) {
				System.out.println("Please enter mail id ");

				MailId = in.next();

				if (imp.validateMailId(MailId)) {
					//System.out.println("\nvalid mail id\n\n");
					break;
				} else {
					System.out.println("Invalid mail id");
				}
			}

			pd.setCustomerName(CName);
			pd.setMailId(MailId);
			pd.setMobileId(MobileID);
			pd.setPhoneNumber(PhoneNumber);
			pd.setPurchasedate(Purchasedate);
			try {
				imp.purchaseMobile(pd);
				System.out.println("your purchase ID: " + imp.getPurchaseseqId());
				imp.updateMobileQuantity(pd);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			throw new MobilePurchaseException(e.getMessage());
		}

	}

	private static void addNewStockInputs() throws MobilePurchaseException {
		Mobiles ms = new Mobiles();
		String name;
		double price;
		int quantity;
		try {

			System.out.println("Enter mobile name:");
			in.nextLine();
			name = in.nextLine();
			System.out.println("Enter price");
			price = in.nextFloat();
			System.out.println("Enter Quantity");
			quantity = in.nextInt();

			ms.setName(name);
			ms.setPrice(price);
			ms.setQuantity(quantity);

			imp.addNewStock(ms);

		} catch (MobilePurchaseException e) {
			throw new MobilePurchaseException("new stock not updated");
		}
	}

}
