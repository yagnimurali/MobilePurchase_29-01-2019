package com.capgemini.MobilePurchase.service;

import java.util.List;

import com.capgemini.MobilePurchase.beans.Mobiles;
import com.capgemini.MobilePurchase.beans.Purchasedetails;
import com.capgemini.MobilePurchase.beans.Seller;
import com.capgemini.MobilePurchase.exceptions.MobilePurchaseException;

public interface IMobilePurchaseService {
	boolean validateCustomerName(String cname);

	boolean validatePhoneNumber(String PhoneNumber);

	boolean validateMobileId(String MobileId);

	boolean validateMailId(String MailId);

	public Purchasedetails purchaseMobile(Purchasedetails pd) throws MobilePurchaseException;

	public List<Mobiles> retriveAllDetails() throws MobilePurchaseException;

	public int getPurchaseseqId() throws MobilePurchaseException;

	public List<Integer> getMobileIds() throws MobilePurchaseException;

	public void updateMobileQuantity(Purchasedetails pd) throws MobilePurchaseException;

	public List<Object> seearchMobile(double minPrice,double maxPrice) throws MobilePurchaseException;

	public Mobiles addNewStock(Mobiles ms) throws MobilePurchaseException;
	
	//public boolean authenticateUser(String username, String password) throws MobilePurchaseException;
	
	public void deleteMobile(int mobileId) throws MobilePurchaseException ;

}
