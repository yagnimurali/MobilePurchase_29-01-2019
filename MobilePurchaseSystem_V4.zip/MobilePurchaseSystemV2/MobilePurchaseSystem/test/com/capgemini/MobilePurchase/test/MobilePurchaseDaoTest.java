package com.capgemini.MobilePurchase.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.MobilePurchase.beans.Mobiles;
import com.capgemini.MobilePurchase.beans.Purchasedetails;
import com.capgemini.MobilePurchase.dao.MobilePurchaseDaoImp;
import com.capgemini.MobilePurchase.exceptions.MobilePurchaseException;

public class MobilePurchaseDaoTest {
	static MobilePurchaseDaoImp daoimp;
	static Purchasedetails pdtest;
	static Mobiles mdtest;
	
	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		daoimp = new MobilePurchaseDaoImp();
		
		pdtest = new Purchasedetails();
		
		mdtest = new Mobiles();
	}
	
	@Test
	public void testPurchaseMobile() throws MobilePurchaseException {
		assertNotNull(daoimp.purchaseMobile(pdtest));
	}
	
	@Test
	public void testPurchaseMobile1() throws MobilePurchaseException {
		assertNotNull(daoimp.addNewStock(mdtest));
	}
	
	@Test
	public void testPurchaseMobile2() throws MobilePurchaseException {	
		pdtest.setCustomerName("Mali");
		pdtest.setMailId("yagni@gmail.o");
		pdtest.setPhoneNumber("7893922340");
		pdtest.setMobileId(1003);
		assertTrue("Data Inserted successfully",
				(daoimp.purchaseMobile(pdtest)).equals(pdtest));	

	}
	
	@Test
	public void testSearch() throws MobilePurchaseException{
		List<Object> mb = new ArrayList<Object>();
		Mobiles m1 = new Mobiles();
		m1.setMobileid(1015);
		m1.setName("sony");
		m1.setPrice(10000);
		m1.setQuantity(20);
		
		mb = daoimp.seearchMobile(5000, 11000);
		
		if (mb != null) 
		{
		Iterator<Object> i = mb.iterator();
		while (i.hasNext()) 
		{
		Mobiles obj = (Mobiles) i
		.next();
		//  Assert.assertNotSame(obj,sm1);
		Assert.assertNotSame(0,obj.getMobileid());
		Assert.assertNotSame("samsung",obj.getName());
		Assert.assertNotSame(35000,obj.getPrice());
		Assert.assertNotSame(28,obj.getQuantity());
		}
		}
		
	}
	

}
